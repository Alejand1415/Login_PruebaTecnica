package com.example.login_pruebatecnica.model;

public class DatosApi {

    private String id;
    private String type;
    private String name;
    private String ppu;
    private String batters;
    private String topping;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPpu() {
        return ppu;
    }

    public void setPpu(String ppu) {
        this.ppu = ppu;
    }

    public String getBatters() {
        return batters;
    }

    public void setBatters(String batters) {
        this.batters = batters;
    }

    public String getTopping() {
        return topping;
    }

    public void setTopping(String topping) {
        this.topping = topping;
    }
}