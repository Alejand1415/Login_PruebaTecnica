package com.example.login_pruebatecnica.network;

import com.example.login_pruebatecnica.model.DatosApi;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface GetApi {

    @GET("v1/eeced007-6b29-4c9d-ab63-c115a990d927")
    Call<List<DatosApi>> getDatosApi();

}
