package com.example.login_pruebatecnica;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.login_pruebatecnica.adapter.ApiAdapter;
import com.example.login_pruebatecnica.model.DatosApi;
import com.example.login_pruebatecnica.network.ApiClient;
import com.example.login_pruebatecnica.network.GetApi;

import org.json.JSONObject;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;

public class DatosRV extends AppCompatActivity {

    Button btnRegresarMA;
    CardView cvDatos;
    private List<DatosApi> datosApis;
    private RecyclerView recyclerView;
    private ApiAdapter apiAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_datos_rv);

        btnRegresarMA = (Button) findViewById(R.id.btnRegresarMA);
        cvDatos = (CardView) findViewById(R.id.cvDatos);
        recyclerView = findViewById(R.id.rvApiD);
        recyclerView.setLayoutManager(new GridLayoutManager(getApplicationContext(), 2));

        String URL = "https://mocki.io/v1/eeced007-6b29-4c9d-ab63-c115a990d927";

        RequestQueue requestQueue = Volley.newRequestQueue(DatosRV.this);

        JsonObjectRequest objectRequest = new JsonObjectRequest(
                Request.Method.GET, URL, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                Log.e("Rest Response", response.toString());

            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Log.e("Rest Response", error.toString());

                    }
                }
        );

        requestQueue.add(objectRequest);

        btnRegresarMA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(DatosRV.this, "Sesión cerrada exitosamente.", Toast.LENGTH_SHORT).show();
                Intent intent8 = new Intent(getApplication(), MainActivity.class);
                startActivity(intent8);

            }
        });

    }
}