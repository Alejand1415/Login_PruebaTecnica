package com.example.login_pruebatecnica;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class DatosRegistro extends AppCompatActivity {

    EditText etNewUsuario, etNewContraseña;
    Button btnNewUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_datos_registro);

        etNewUsuario = (EditText) findViewById(R.id.etNewUsuario);
        etNewContraseña = (EditText) findViewById(R.id.etNewContraseña);
        btnNewUser = (Button) findViewById(R.id.btnNewUser);

        btnNewUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String username = etNewUsuario.getText().toString();
                String password = etNewContraseña.getText().toString();

                SharedPreferences sharedPreferences = getSharedPreferences("user_data", MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("username", username);
                editor.putString("password", password);
                editor.apply();

                Toast.makeText(DatosRegistro.this, "Registro creado exitosamente.", Toast.LENGTH_SHORT).show();

                Intent intent6 = new Intent(getApplication(), MainActivity.class);
                startActivity(intent6);

            }
        });

    }
}