package com.example.login_pruebatecnica;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText etUsuario, etPassword;
    Button btnIngresar, btnRegistrar, btnSalir, btnMA;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etUsuario = (EditText) findViewById(R.id.etNewUsuario);
        etPassword = (EditText) findViewById(R.id.etPassword);
        btnIngresar = (Button) findViewById(R.id.btnNewUser);
        btnRegistrar = (Button) findViewById(R.id.btnRegistrar);
        btnSalir = (Button) findViewById(R.id.btnSalir);
        btnMA = (Button) findViewById(R.id.btnMA);

        btnIngresar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String username = etUsuario.getText().toString();
                String password = etPassword.getText().toString();

                Intent intent6 = getIntent();

                String textoUsuario = intent6.getStringExtra("textoExtra");

                etUsuario.setText(textoUsuario);
                etPassword.setText(textoUsuario);

                if (username.equals("Diego Alejandro") && password.equals("usr1415")) {
                    Toast.makeText(MainActivity.this, "Inicio de sesión exitoso. Bienvenido Diego.", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getApplication(), DatosLogin.class);
                    intent.putExtra("textoExtra", username);
                    startActivity(intent);

                } else {
                    Toast.makeText(MainActivity.this, "Inicio de sesión fallido. Verifica tus usuario o contraseña.", Toast.LENGTH_SHORT).show();

                }
            }
        });

        btnRegistrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(MainActivity.this, "Sigue los pasos descritos.", Toast.LENGTH_SHORT).show();
                Intent intent2 = new Intent(getApplication(), DatosRegistro.class);
                startActivity(intent2);

            }
        });

        btnSalir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(MainActivity.this, "Espero vuelvas pronto.", Toast.LENGTH_SHORT).show();
                finishAffinity();

            }
        });

        btnMA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent10 = new Intent(getApplication(), DatosLogin.class);
                startActivity(intent10);

            }
        });
    }
}